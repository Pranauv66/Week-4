# CyberShield X

CyberShield X is a static HTML/CSS security operations interface served through a lightweight Node.js HTTP server.

## Run locally

Requirements: Node.js 18 or newer.

```powershell
npm start
```

Open http://localhost:3000 in a browser.

For automatic server restart during edits:

```powershell
npm run dev
```

Set a different port in PowerShell with:

```powershell
$env:PORT=8080; npm start
```
# CyberShield X

Static frontend project for the CyberShield X enterprise cyber defense command center.

## Structure

- `index.html` — main command center landing page
- `threats.html` — threat intelligence overview
- `threat-field.html` — global threat field
- `network.html` — network universe
- `attack-paths.html` — attack path analysis
- `incidents.html` — incident investigation
- `analytics.html` — security analytics
- `reports.html` — security reports
- `team.html` — security team
- `settings.html` — settings
- `login.html` — login UI
- `signup.html` — registration UI

## CSS

The project uses a structured CSS architecture:

- `css/variables.css`
- `css/reset.css`
- `css/typography.css`
- `css/layout.css`
- `css/components.css`
- `css/dashboard.css`
- `css/visualizations.css`
- `css/animations.css`
- `css/responsive.css`
- `css/accessibility.css`

## Data

Static JSON files are placed under `data/` for future frontend data modeling.

## Notes

This project is intentionally a static HTML/CSS/SVG implementation for the initial architecture phase.
